<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-bold text-slate-800 sm:text-2xl">
                    Detail Inspeksi Gerai
                </h2>

                <p class="mt-1 text-sm text-slate-500">
                    Nomor inspeksi:
                    <span class="font-semibold text-[#17365D]">
                        <?php echo e($inspection->inspection_number ?? 'INS-' . $inspection->id); ?>

                    </span>
                </p>
            </div>

            <div class="flex flex-wrap gap-2">
                <a href="<?php echo e(route('inspections.index')); ?>"
                   class="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50">
                    Kembali
                </a>

                <a href="<?php echo e(route('inspections.edit', $inspection)); ?>"
                   class="inline-flex items-center justify-center rounded-lg bg-[#17365D] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#28558A]">
                    Edit Inspeksi
                </a>

                <a href="<?php echo e(route('inspections.pdf', $inspection)); ?>"
                   class="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50">
                    <svg xmlns="http://www.w3.org/2000/svg"
                         class="h-4 w-4"
                         fill="none"
                         viewBox="0 0 24 24"
                         stroke="currentColor"
                         stroke-width="2">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              d="M12 3v12m0 0l-4-4m4 4l4-4M5 17v3h14v-3"/>
                    </svg>
                    Download PDF
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-slate-50 py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">

            
            <?php if(session('success')): ?>
                <div role="alert"
                     class="rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-800">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div role="alert"
                     class="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div role="alert"
                     class="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
                    <p class="mb-2 font-semibold">Terdapat kesalahan:</p>
                    <ul class="list-inside list-disc space-y-1">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h3 class="text-base font-bold text-slate-800">
                                Informasi Inspeksi
                            </h3>
                            <p class="mt-1 text-sm text-slate-500">
                                Informasi umum mengenai pelaksanaan inspeksi gerai.
                            </p>
                        </div>

                        <?php
                            $status = $inspection->status ?? 'draft';

                            $statusClass = match ($status) {
                                'completed' => 'bg-green-100 text-green-800',
                                'in_progress' => 'bg-blue-100 text-blue-800',
                                'cancelled' => 'bg-red-100 text-red-800',
                                default => 'bg-amber-100 text-amber-800',
                            };
                        ?>

                        <span class="inline-flex w-fit items-center rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($statusClass); ?>">
                            <?php echo e(ucfirst(str_replace('_', ' ', $status))); ?>

                        </span>
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-5 p-6 sm:grid-cols-2 lg:grid-cols-3">
                    <div>
                        <p class="text-sm text-slate-500">Nomor Inspeksi</p>
                        <p class="mt-1 break-words font-semibold text-slate-900">
                            <?php echo e($inspection->inspection_number ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Nama Mitra</p>
                        <p class="mt-1 break-words font-medium text-slate-900">
                            <?php echo e($inspection->partner_name ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Brand</p>
                        <p class="mt-1 break-words font-medium text-slate-900">
                            <?php echo e($inspection->brand ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Kode Ruangan</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->room_code ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Kategori</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->category ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Lokasi</p>
                        <p class="mt-1 break-words font-medium text-slate-900">
                            <?php echo e($inspection->location ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Jenis Inspeksi</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->inspection_type ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Tanggal Inspeksi</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->inspection_date?->format('d/m/Y') ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Waktu Inspeksi</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->inspection_time ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Nama Inspektor</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->inspector_name ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Jabatan Inspektor</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->inspector_position ?? '-'); ?>

                        </p>
                    </div>

                    <div>
                        <p class="text-sm text-slate-500">Terminal</p>
                        <p class="mt-1 font-medium text-slate-900">
                            <?php echo e($inspection->terminal ?? '-'); ?>

                        </p>
                    </div>

                    <div class="sm:col-span-2 lg:col-span-3">
                        <p class="text-sm text-slate-500">Catatan Umum</p>
                        <p class="mt-1 whitespace-pre-line text-sm leading-6 text-slate-700">
                            <?php echo e($inspection->notes ?: 'Tidak ada catatan umum.'); ?>

                        </p>
                    </div>
                </div>
            </section>

            
            <?php
                $totalChecklist = $checklistItems->count();
                $totalSesuai = $checklistItems->where('status', 'sesuai')->count();
                $totalTidakSesuai = $checklistItems->where('status', 'tidak_sesuai')->count();
                $totalTidakBerlaku = $checklistItems->where('status', 'tidak_berlaku')->count();
                $totalBelumDiperiksa = $checklistItems->filter(
                    fn ($item) => !in_array(
                        $item->status,
                        ['sesuai', 'tidak_sesuai', 'tidak_berlaku'],
                        true
                    )
                )->count();

                $totalSelesai = $totalChecklist - $totalBelumDiperiksa;
                $persentaseChecklist = $totalChecklist > 0
                    ? round(($totalSelesai / $totalChecklist) * 100)
                    : 0;
            ?>

            <section class="space-y-4">
                <div>
                    <h3 class="text-lg font-bold text-slate-800">
                        Ringkasan Pemeriksaan
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Pantau progres pemeriksaan seluruh kriteria inspeksi.
                    </p>
                </div>

                <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
                    <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                        <p class="text-sm font-medium text-slate-500">Total Kriteria</p>
                        <p class="mt-2 text-3xl font-bold text-[#17365D]">
                            <?php echo e($totalChecklist); ?>

                        </p>
                    </div>

                    <div class="rounded-xl border border-green-200 bg-green-50 p-5">
                        <p class="text-sm font-medium text-green-700">Sesuai</p>
                        <p class="mt-2 text-3xl font-bold text-green-700">
                            <?php echo e($totalSesuai); ?>

                        </p>
                    </div>

                    <div class="rounded-xl border border-red-200 bg-red-50 p-5">
                        <p class="text-sm font-medium text-red-700">Tidak Sesuai</p>
                        <p class="mt-2 text-3xl font-bold text-red-700">
                            <?php echo e($totalTidakSesuai); ?>

                        </p>
                    </div>

                    <div class="rounded-xl border border-slate-200 bg-white p-5">
                        <p class="text-sm font-medium text-slate-600">Tidak Berlaku</p>
                        <p class="mt-2 text-3xl font-bold text-slate-700">
                            <?php echo e($totalTidakBerlaku); ?>

                        </p>
                    </div>

                    <div class="rounded-xl border border-amber-200 bg-amber-50 p-5">
                        <p class="text-sm font-medium text-amber-700">Belum Diperiksa</p>
                        <p class="mt-2 text-3xl font-bold text-amber-700">
                            <?php echo e($totalBelumDiperiksa); ?>

                        </p>
                    </div>
                </div>

                <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div class="mb-3 flex items-center justify-between gap-3">
                        <div>
                            <p class="font-semibold text-slate-800">Progres Checklist</p>
                            <p class="mt-1 text-xs text-slate-500">
                                <?php echo e($totalSelesai); ?> dari <?php echo e($totalChecklist); ?> kriteria telah diperiksa.
                            </p>
                        </div>

                        <span class="text-lg font-bold text-[#17365D]">
                            <?php echo e($persentaseChecklist); ?>%
                        </span>
                    </div>

                    <div class="h-3 overflow-hidden rounded-full bg-slate-100">
                        <div class="h-full rounded-full bg-[#17365D] transition-all duration-300"
                             style="width: <?php echo e($persentaseChecklist); ?>%">
                        </div>
                    </div>
                </div>
            </section>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <h3 class="text-base font-bold text-slate-800">
                        Tambah Kriteria Checklist
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Tambahkan kriteria pemeriksaan khusus sesuai kebutuhan inspeksi gerai.
                    </p>
                </div>

                <form action="<?php echo e(route('inspections.checklist-items.store', $inspection)); ?>"
                      method="POST"
                      class="space-y-5 p-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label for="new_section_code"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Bagian Checklist
                        </label>

                        <select name="section_code"
                                id="new_section_code"
                                required
                                class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">
                            <?php $__currentLoopData = config('inspection_checklist', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($section['code']); ?>"
                                    <?php if(old('section_code') == $section['code']): echo 'selected'; endif; ?>>
                                    Bagian <?php echo e($section['code']); ?> — <?php echo e($section['name']); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="new_code"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Kode Kriteria
                            <span class="font-normal text-slate-400">(opsional)</span>
                        </label>

                        <input type="text"
                               name="code"
                               id="new_code"
                               value="<?php echo e(old('code')); ?>"
                               maxlength="20"
                               placeholder="Contoh: A4 atau C16"
                               class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">

                        <p class="mt-1 text-xs text-slate-500">
                            Isi kode sendiri jika diperlukan. Boleh dikosongkan.
                        </p>
                    </div>

                    <div>
                        <label for="new_criteria"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Kriteria Pemeriksaan
                        </label>

                        <textarea name="criteria"
                                  id="new_criteria"
                                  rows="3"
                                  required
                                  maxlength="2000"
                                  placeholder="Tuliskan kriteria pemeriksaan yang ingin ditambahkan..."
                                  class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]"><?php echo e(old('criteria')); ?></textarea>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit"
                                class="inline-flex items-center rounded-lg bg-[#17365D] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#28558A] focus:outline-none focus:ring-2 focus:ring-[#17365D] focus:ring-offset-2">
                            + Tambah Kriteria
                        </button>
                    </div>
                </form>
            </section>

            
            <form action="<?php echo e(route('inspections.checklist.save', $inspection)); ?>"
                  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h2 class="text-lg font-bold text-slate-800">
                            Checklist Inspeksi
                        </h2>
                        <p class="mt-1 text-sm text-slate-500">
                            Pilih status setiap kriteria dan tambahkan catatan jika diperlukan.
                        </p>
                    </div>

                    <button type="submit"
                            class="rounded-lg bg-[#17365D] px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#28558A]">
                        Simpan Checklist
                    </button>
                </div>

                <?php $__currentLoopData = config('inspection_checklist', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $sectionItems = $checklistItems
                            ->where('section_code', $section['code'])
                            ->sortBy('sort_order');
                    ?>

                    <section class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
                            <h3 class="font-bold text-slate-800">
                                <?php echo e($section['code']); ?>. <?php echo e($section['name']); ?>

                            </h3>
                            <p class="mt-1 text-xs text-slate-500">
                                <?php echo e($sectionItems->count()); ?> kriteria
                            </p>
                        </div>

                        <div class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $sectionItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="p-5">
                                    <div class="grid grid-cols-1 gap-5 lg:grid-cols-12">
                                        <div class="lg:col-span-5">
                                            <div class="flex flex-col items-start gap-2">
                                                <?php if($item->code): ?>
                                                    <span class="inline-flex h-fit rounded-md bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                                                        <?php echo e($item->code); ?>

                                                    </span>
                                                <?php endif; ?>

                                                <p class="w-full text-sm font-medium leading-6 text-slate-800">
                                                    <?php echo e($item->criteria); ?>

                                                </p>

                                                <?php if($item->is_custom): ?>
                                                    <span class="inline-flex h-fit rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-[#17365D]">
                                                        Kriteria Tambahan
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="lg:col-span-4">
                                            <p class="mb-2 text-xs font-medium text-slate-500">
                                                Status Pemeriksaan
                                            </p>

                                            <div class="grid grid-cols-1 gap-2 sm:grid-cols-3">
                                                <?php $__currentLoopData = [
                                                    'sesuai' => 'Sesuai',
                                                    'tidak_sesuai' => 'Tidak Sesuai',
                                                    'tidak_berlaku' => 'Tidak Berlaku',
                                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 p-2.5 transition hover:border-slate-300 hover:bg-slate-50 sm:flex-col sm:justify-center sm:gap-1 sm:text-center">
                                                        <input type="radio"
                                                               name="checklist[<?php echo e($item->id); ?>][status]"
                                                               value="<?php echo e($value); ?>"
                                                               <?php if(old("checklist.{$item->id}.status", $item->status) === $value): echo 'checked'; endif; ?>
                                                               class="h-4 w-4 cursor-pointer border-slate-300 text-[#17365D] focus:ring-[#17365D]">

                                                        <span class="text-xs text-slate-700">
                                                            <?php echo e($label); ?>

                                                        </span>
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>

                                        <div class="lg:col-span-3">
                                            <label for="notes_<?php echo e($item->id); ?>"
                                                   class="mb-2 block text-xs font-medium text-slate-500">
                                                Catatan
                                            </label>

                                            <textarea name="checklist[<?php echo e($item->id); ?>][notes]"
                                                      id="notes_<?php echo e($item->id); ?>"
                                                      rows="3"
                                                      maxlength="2000"
                                                      placeholder="Catatan jika ada..."
                                                      class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]"><?php echo e(old("checklist.{$item->id}.notes", $item->notes)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="p-6 text-center text-sm text-slate-500">
                                    Belum ada kriteria untuk bagian ini.
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php
                    $configuredSectionCodes = collect(config('inspection_checklist', []))
                        ->pluck('code');

                    $unconfiguredItems = $checklistItems
                        ->filter(fn ($item) => !$configuredSectionCodes->contains($item->section_code));
                ?>

                <?php if($unconfiguredItems->isNotEmpty()): ?>
                    <section class="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div class="border-b border-slate-200 bg-slate-50 px-5 py-4">
                            <h3 class="font-bold text-slate-800">
                                Kriteria Tambahan Lainnya
                            </h3>
                        </div>

                        <div class="divide-y divide-slate-100">
                            <?php $__currentLoopData = $unconfiguredItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-5">
                                    <div class="grid grid-cols-1 gap-5 lg:grid-cols-12">
                                        <div class="lg:col-span-5">
                                            <?php if($item->code): ?>
                                                <span class="inline-flex rounded-md bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                                                    <?php echo e($item->code); ?>

                                                </span>
                                            <?php endif; ?>

                                            <p class="mt-2 text-sm leading-6 text-slate-800">
                                                <?php echo e($item->criteria); ?>

                                            </p>
                                        </div>

                                        <div class="lg:col-span-4">
                                            <p class="mb-2 text-xs font-medium text-slate-500">
                                                Status Pemeriksaan
                                            </p>

                                            <div class="space-y-2">
                                                <?php $__currentLoopData = [
                                                    'sesuai' => 'Sesuai',
                                                    'tidak_sesuai' => 'Tidak Sesuai',
                                                    'tidak_berlaku' => 'Tidak Berlaku',
                                                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="flex items-center gap-2 rounded-lg border border-slate-200 p-2.5">
                                                        <input type="radio"
                                                               name="checklist[<?php echo e($item->id); ?>][status]"
                                                               value="<?php echo e($value); ?>"
                                                               <?php if(old("checklist.{$item->id}.status", $item->status) === $value): echo 'checked'; endif; ?>
                                                               class="h-4 w-4 border-slate-300 text-[#17365D] focus:ring-[#17365D]">

                                                        <span class="text-sm text-slate-700">
                                                            <?php echo e($label); ?>

                                                        </span>
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>

                                        <div class="lg:col-span-3">
                                            <label for="notes_extra_<?php echo e($item->id); ?>"
                                                   class="mb-2 block text-xs font-medium text-slate-500">
                                                Catatan
                                            </label>

                                            <textarea name="checklist[<?php echo e($item->id); ?>][notes]"
                                                      id="notes_extra_<?php echo e($item->id); ?>"
                                                      rows="3"
                                                      maxlength="2000"
                                                      placeholder="Catatan jika ada..."
                                                      class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]"><?php echo e(old("checklist.{$item->id}.notes", $item->notes)); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                <?php endif; ?>

                <div class="sticky bottom-4 z-10 flex justify-end">
                    <button type="submit"
                            class="rounded-lg bg-[#17365D] px-6 py-3 text-sm font-semibold text-white shadow-lg transition hover:bg-[#28558A] focus:outline-none focus:ring-2 focus:ring-[#17365D] focus:ring-offset-2">
                        Simpan Checklist
                    </button>
                </div>
            </form>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <h3 class="text-base font-bold text-slate-800">
                        Tambah Temuan Inspeksi
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Catat kondisi atau ketidaksesuaian yang ditemukan saat pemeriksaan.
                    </p>
                </div>

                <form action="<?php echo e(route('inspections.findings.store', $inspection)); ?>"
                      method="POST"
                      class="space-y-5 p-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label for="checklist_item_id"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Kriteria Checklist
                            <span class="font-normal text-slate-400">(opsional)</span>
                        </label>

                        <select name="checklist_item_id"
        id="checklist_item_id"
        class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">

    <option value="">-- Pilih Kriteria Tidak Sesuai --</option>

    <?php $__currentLoopData = $checklistItems->where('status', 'tidak_sesuai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>"
            <?php if(old('checklist_item_id') == $item->id): echo 'selected'; endif; ?>>
            <?php echo e($item->code ? $item->code . ' - ' : ''); ?>

            <?php echo e($item->criteria); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>
                    </div>

                    <div>
                        <label for="finding_description"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Deskripsi Temuan
                        </label>

                        <textarea name="description"
                                  id="finding_description"
                                  rows="4"
                                  maxlength="5000"
                                  required
                                  placeholder="Jelaskan temuan inspeksi secara rinci..."
                                  class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]"><?php echo e(old('description')); ?></textarea>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit"
                                class="rounded-lg bg-[#17365D] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#28558A]">
                            Simpan Temuan
                        </button>
                    </div>
                </form>
            </section>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <h3 class="text-base font-bold text-slate-800">
                        Daftar Temuan Inspeksi
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Temuan yang telah dicatat selama pemeriksaan.
                    </p>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $findings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-b border-slate-100 p-5 last:border-b-0">
                        <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                            <?php if($finding->code): ?>
                                <span class="inline-flex w-fit rounded-md bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-700">
                                    <?php echo e($finding->code); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if($finding->criteria): ?>
                            <p class="mt-2 text-sm font-semibold text-slate-800">
                                <?php echo e($finding->criteria); ?>

                            </p>
                        <?php endif; ?>

                        <p class="mt-2 whitespace-pre-line text-sm leading-6 text-slate-600">
                            <?php echo e($finding->description); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="p-6 text-center text-sm text-slate-500">
                        Belum ada temuan inspeksi.
                    </div>
                <?php endif; ?>
            </section>

            
            <?php
                $signatureParties = [
                    'pihak_pertama' => [
                        'label' => 'Pihak Pertama',
                        'company' => 'PT ANGKASA PURA INDONESIA (PERSERO)',
                        'name' => $inspection->inspector_name,
                        'position' => $inspection->inspector_position,
                        'editable_name' => false,
                    ],
                    'pihak_kedua' => [
                        'label' => 'Pihak Kedua',
                        'company' => $inspection->partner_name,
                        'name' => '',
                        'position' => '',
                        'editable_name' => true,
                    ],
                ];
            ?>

            <section class="space-y-5">
                <div>
                    <h3 class="text-lg font-bold text-slate-800">
                        Tanda Tangan Para Pihak
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Lengkapi tanda tangan setelah seluruh checklist dan daftar temuan inspeksi selesai.
                    </p>
                </div>

                <?php $__currentLoopData = $signatureParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyKey => $partyData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $partySignature = $signatures->firstWhere('party', $partyKey);

                        $companyValue = $partyData['company'] ?? '';

                        $nameValue = $partyData['editable_name']
                            ? ($partySignature?->name ?? '')
                            : ($partyData['name'] ?? '');

                        $positionValue = $partyData['editable_name']
                            ? ($partySignature?->position ?? '')
                            : ($partyData['position'] ?? '');

                        $signatureSaved = $partySignature
                            && !empty($partySignature->signature_path);
                    ?>

                    <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div class="border-b border-slate-100 bg-slate-50 px-6 py-5">
                            <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <h4 class="text-base font-bold text-slate-800">
                                        <?php echo e($partyData['label']); ?>

                                    </h4>

                                    <?php if($signatureSaved): ?>
                                        <p class="mt-1 text-xs text-green-700">
                                            Tanda tangan tersimpan:
                                            <?php echo e($partySignature->signed_at?->format('d/m/Y H:i') ?? '-'); ?>

                                        </p>
                                    <?php else: ?>
                                        <p class="mt-1 text-xs text-amber-700">
                                            Belum ada tanda tangan tersimpan.
                                        </p>
                                    <?php endif; ?>
                                </div>

                                <span class="inline-flex w-fit rounded-full px-3 py-1 text-xs font-semibold <?php echo e($signatureSaved ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'); ?>">
                                    <?php echo e($signatureSaved ? 'Sudah Ditandatangani' : 'Menunggu Tanda Tangan'); ?>

                                </span>
                            </div>
                        </div>

                        <form action="<?php echo e(route('inspections.signatures.save', $inspection)); ?>"
                              method="POST"
                              enctype="multipart/form-data"
                              class="space-y-5 p-6"
                              id="signature-form-<?php echo e($partyKey); ?>">
                            <?php echo csrf_field(); ?>

                            <input type="hidden"
                                   name="party"
                                   value="<?php echo e($partyKey); ?>">

                            <input type="hidden"
                                   name="signature_data"
                                   id="signature-data-<?php echo e($partyKey); ?>">

                            
                            <div>
                                <label for="signature-company-<?php echo e($partyKey); ?>"
                                       class="mb-2 block text-sm font-medium text-slate-700">
                                    Nama Perusahaan
                                </label>

                                <input type="text"
                                       id="signature-company-<?php echo e($partyKey); ?>"
                                       value="<?php echo e($companyValue); ?>"
                                       readonly
                                       class="w-full rounded-lg border-slate-300 bg-slate-50 text-sm text-slate-700 shadow-sm">

                                <input type="hidden"
                                       name="company_name"
                                       value="<?php echo e($companyValue); ?>">
                            </div>

                            
                            <?php if($partyData['editable_name']): ?>
                                <div>
                                    <label for="signature-name-<?php echo e($partyKey); ?>"
                                           class="mb-2 block text-sm font-medium text-slate-700">
                                        Nama Perwakilan Mitra
                                    </label>

                                    <input type="text"
                                           name="name"
                                           id="signature-name-<?php echo e($partyKey); ?>"
                                           value="<?php echo e(old('party') === $partyKey ? old('name') : $nameValue); ?>"
                                           maxlength="255"
                                           required
                                           class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">
                                </div>

                                <div>
                                    <label for="signature-position-<?php echo e($partyKey); ?>"
                                           class="mb-2 block text-sm font-medium text-slate-700">
                                        Jabatan Perwakilan Mitra
                                    </label>

                                    <input type="text"
                                           name="position"
                                           id="signature-position-<?php echo e($partyKey); ?>"
                                           value="<?php echo e(old('party') === $partyKey ? old('position') : $positionValue); ?>"
                                           maxlength="255"
                                           required
                                           class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">
                                </div>
                            <?php else: ?>
                                <div>
                                    <label class="mb-2 block text-sm font-medium text-slate-700">
                                        Nama Inspektor
                                    </label>

                                    <input type="text"
                                           value="<?php echo e($partyData['name'] ?? ''); ?>"
                                           readonly
                                           class="w-full rounded-lg border-slate-300 bg-slate-50 text-sm text-slate-700 shadow-sm">

                                    <input type="hidden"
                                           name="name"
                                           value="<?php echo e($partyData['name'] ?? ''); ?>">
                                </div>

                                <div>
                                    <label class="mb-2 block text-sm font-medium text-slate-700">
                                        Jabatan Inspektor
                                    </label>

                                    <input type="text"
                                           value="<?php echo e($partyData['position'] ?? ''); ?>"
                                           readonly
                                           class="w-full rounded-lg border-slate-300 bg-slate-50 text-sm text-slate-700 shadow-sm">

                                    <input type="hidden"
                                           name="position"
                                           value="<?php echo e($partyData['position'] ?? ''); ?>">
                                </div>
                            <?php endif; ?>

                            
                            <div>
                                <label class="mb-2 block text-sm font-medium text-slate-700">
                                    Tanda Tangan
                                </label>

                                <div class="overflow-hidden rounded-xl border border-slate-200 bg-white">
                                    <canvas id="signature-canvas-<?php echo e($partyKey); ?>"
                                            width="700"
                                            height="220"
                                            class="block w-full touch-none"
                                            style="height:220px; cursor:crosshair;">
                                    </canvas>
                                </div>

                                <p class="mt-2 text-xs text-slate-500">
                                    Gunakan mouse, stylus, atau layar sentuh untuk membuat tanda tangan.
                                </p>

                                <div class="mt-3 flex flex-wrap items-center gap-3">
                                    <button type="button"
                                            data-clear-signature="<?php echo e($partyKey); ?>"
                                            class="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50">
                                        Hapus Gambar
                                    </button>
                                </div>
                            </div>

                            <div class="flex items-center gap-3">
                                <div class="h-px flex-1 bg-slate-200"></div>
                                <span class="text-xs font-semibold tracking-wide text-slate-400">
                                    ATAU UPLOAD GAMBAR
                                </span>
                                <div class="h-px flex-1 bg-slate-200"></div>
                            </div>

                            
                            <div>
                                <label for="signature-upload-<?php echo e($partyKey); ?>"
                                       class="mb-2 block text-sm font-medium text-slate-700">
                                    Upload Tanda Tangan
                                </label>

                                <input type="file"
                                       name="signature_upload"
                                       id="signature-upload-<?php echo e($partyKey); ?>"
                                       accept=".png,.jpg,.jpeg,image/png,image/jpeg"
                                       class="block w-full rounded-lg border border-slate-200 text-sm text-slate-700 file:mr-4 file:rounded-l-lg file:border-0 file:bg-slate-100 file:px-4 file:py-3 file:font-medium file:text-[#17365D] hover:file:bg-slate-200">

                                <p class="mt-1 text-xs text-slate-500">
                                    Format PNG, JPG, atau JPEG. Ukuran maksimal 2 MB.
                                </p>
                            </div>

                            <div class="flex justify-end">
                                <button type="submit"
                                        class="rounded-lg bg-[#17365D] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#28558A] focus:outline-none focus:ring-2 focus:ring-[#17365D] focus:ring-offset-2">
                                    Simpan <?php echo e($partyData['label']); ?>

                                </button>
                            </div>
                        </form>

                        
                        <?php if($signatureSaved): ?>
                            <div class="border-t border-slate-100 bg-slate-50 p-6">
                                <p class="mb-3 text-sm font-semibold text-slate-700">
                                    Pratinjau Tanda Tangan Tersimpan
                                </p>

                                <div class="rounded-xl border border-slate-200 bg-white p-4">
                                    <img src="<?php echo e(asset('storage/' . $partySignature->signature_path)); ?>"
                                         alt="Tanda tangan <?php echo e($partyData['label']); ?>"
                                         class="max-h-40 max-w-full object-contain">

                                    <div class="mt-4 border-t border-slate-100 pt-4">
                                        <p class="font-semibold text-slate-800">
                                            <?php echo e($nameValue ?: '-'); ?>

                                        </p>

                                        <p class="text-sm text-slate-600">
                                            <?php echo e($positionValue ?: '-'); ?>

                                        </p>

                                        <p class="mt-1 text-sm text-slate-500">
                                            <?php echo e($companyValue ?: '-'); ?>

                                        </p>

                                        <p class="mt-2 text-xs text-slate-400">
                                            Ditandatangani pada
                                            <?php echo e($partySignature->signed_at?->format('d/m/Y H:i') ?? '-'); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    ['pihak_pertama', 'pihak_kedua'].forEach(function (party) {
                        const canvas = document.getElementById('signature-canvas-' + party);
                        const form = document.getElementById('signature-form-' + party);
                        const hiddenInput = document.getElementById('signature-data-' + party);
                        const uploadInput = document.getElementById('signature-upload-' + party);
                        const clearButton = document.querySelector(
                            '[data-clear-signature="' + party + '"]'
                        );

                        if (!canvas || !form || !hiddenInput) {
                            return;
                        }

                        const ctx = canvas.getContext('2d');

                        let drawing = false;
                        let hasDrawing = false;

                        ctx.strokeStyle = '#111827';
                        ctx.lineWidth = 2.5;
                        ctx.lineCap = 'round';
                        ctx.lineJoin = 'round';

                        function getPosition(event) {
                            const rect = canvas.getBoundingClientRect();

                            return {
                                x: (event.clientX - rect.left) * canvas.width / rect.width,
                                y: (event.clientY - rect.top) * canvas.height / rect.height
                            };
                        }

                        canvas.addEventListener('pointerdown', function (event) {
                            if (event.button !== undefined && event.button !== 0) {
                                return;
                            }

                            drawing = true;
                            hasDrawing = true;

                            if (canvas.setPointerCapture) {
                                canvas.setPointerCapture(event.pointerId);
                            }

                            const point = getPosition(event);

                            ctx.beginPath();
                            ctx.moveTo(point.x, point.y);
                            ctx.lineTo(point.x + 0.1, point.y + 0.1);
                            ctx.stroke();

                            event.preventDefault();
                        });

                        canvas.addEventListener('pointermove', function (event) {
                            if (!drawing) {
                                return;
                            }

                            const point = getPosition(event);

                            ctx.lineTo(point.x, point.y);
                            ctx.stroke();

                            event.preventDefault();
                        });

                        function stopDrawing() {
                            drawing = false;
                            ctx.beginPath();
                        }

                        canvas.addEventListener('pointerup', stopDrawing);
                        canvas.addEventListener('pointercancel', stopDrawing);
                        canvas.addEventListener('lostpointercapture', stopDrawing);

                        clearButton?.addEventListener('click', function () {
                            ctx.clearRect(0, 0, canvas.width, canvas.height);

                            hasDrawing = false;
                            hiddenInput.value = '';

                            if (uploadInput) {
                                uploadInput.value = '';
                            }
                        });

                        uploadInput?.addEventListener('change', function () {
                            if (uploadInput.files && uploadInput.files.length > 0) {
                                hiddenInput.value = '';
                            }
                        });

                        form.addEventListener('submit', function (event) {
                            if (uploadInput?.files?.length > 0) {
                                hiddenInput.value = '';
                                return;
                            }

                            if (!hasDrawing) {
                                event.preventDefault();

                                alert(
                                    'Silakan gambar tanda tangan atau unggah gambar terlebih dahulu.'
                                );

                                return;
                            }

                            hiddenInput.value = canvas.toDataURL('image/png');
                        });
                    });
                });
            </script>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <h3 class="text-base font-bold text-slate-800">
                        Dokumentasi Foto Inspeksi
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Unggah foto kondisi gerai sebagai bukti dokumentasi pemeriksaan.
                    </p>
                </div>

                <form action="<?php echo e(route('inspections.photos.store', $inspection)); ?>"
                      method="POST"
                      enctype="multipart/form-data"
                      class="space-y-5 p-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label for="photo_category"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Kategori Foto
                        </label>

                        <select name="category"
                                id="photo_category"
                                required
                                class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">
                            <option value="temuan" <?php if(old('category') === 'temuan'): echo 'selected'; endif; ?>>
                                Temuan
                            </option>
                            <option value="kondisi_awal" <?php if(old('category') === 'kondisi_awal'): echo 'selected'; endif; ?>>
                                Kondisi Awal
                            </option>
                            <option value="kondisi_akhir" <?php if(old('category') === 'kondisi_akhir'): echo 'selected'; endif; ?>>
                                Kondisi Akhir
                            </option>
                            <option value="lainnya" <?php if(old('category') === 'lainnya'): echo 'selected'; endif; ?>>
                                Lainnya
                            </option>
                        </select>
                    </div>

                    <div>
                        <label for="finding_id"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Temuan Terkait
                            <span class="font-normal text-slate-400">(opsional)</span>
                        </label>

                        <select name="finding_id"
                                id="finding_id"
                                class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]">
                            <option value="">-- Tidak terkait dengan temuan tertentu --</option>

                            <?php $__currentLoopData = $findings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($finding->id); ?>"
                                    <?php if(old('finding_id') == $finding->id): echo 'selected'; endif; ?>>
                                    <?php echo e($finding->code ? $finding->code . ' - ' : ''); ?>

                                    <?php echo e(\Illuminate\Support\Str::limit($finding->description, 100)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="photo"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Pilih Foto
                        </label>

                        <input type="file"
                               name="photo"
                               id="photo"
                               accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                               required
                               class="block w-full rounded-lg border border-slate-200 text-sm text-slate-700 file:mr-4 file:rounded-l-lg file:border-0 file:bg-slate-100 file:px-4 file:py-3 file:font-medium file:text-[#17365D] hover:file:bg-slate-200">

                        <p class="mt-1 text-xs text-slate-500">
                            Format JPG, JPEG, PNG, atau WEBP. Ukuran maksimal 5 MB per foto.
                        </p>
                    </div>

                    <div>
                        <label for="photo_caption"
                               class="mb-2 block text-sm font-medium text-slate-700">
                            Keterangan Foto
                            <span class="font-normal text-slate-400">(opsional)</span>
                        </label>

                        <textarea name="caption"
                                  id="photo_caption"
                                  rows="2"
                                  maxlength="1000"
                                  placeholder="Contoh: Kondisi lantai di depan gerai..."
                                  class="w-full rounded-lg border-slate-300 text-sm shadow-sm focus:border-[#17365D] focus:ring-[#17365D]"><?php echo e(old('caption')); ?></textarea>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit"
                                class="rounded-lg bg-[#17365D] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#28558A]">
                            Upload Foto
                        </button>
                    </div>
                </form>
            </section>

            
            <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="border-b border-slate-100 px-6 py-5">
                    <h3 class="text-base font-bold text-slate-800">
                        Galeri Dokumentasi Foto
                    </h3>
                    <p class="mt-1 text-sm text-slate-500">
                        Dokumentasi foto yang telah diunggah untuk inspeksi ini.
                    </p>
                </div>

                <div class="p-6">
                    <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <article class="mb-5 overflow-hidden rounded-xl border border-slate-200 last:mb-0">
                            <a href="<?php echo e(asset('storage/' . $photo->file_path)); ?>"
                               target="_blank"
                               rel="noopener noreferrer">
                                <img src="<?php echo e(asset('storage/' . $photo->file_path)); ?>"
                                     alt="<?php echo e($photo->caption ?? 'Foto inspeksi'); ?>"
                                     loading="lazy"
                                     class="h-56 w-full bg-slate-50 object-contain sm:h-72">
                            </a>

                            <div class="p-4">
                                <div class="flex flex-wrap items-center gap-2">
                                    <span class="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                                        <?php echo e(ucfirst(str_replace('_', ' ', $photo->category))); ?>

                                    </span>
                                </div>

                                <p class="mt-3 whitespace-pre-line text-sm leading-6 text-slate-600">
                                    <?php echo e($photo->caption ?: 'Tidak ada keterangan foto.'); ?>

                                </p>

                                <?php if($photo->finding_id): ?>
                                    <p class="mt-2 text-xs text-slate-500">
                                        Terhubung dengan temuan #<?php echo e($photo->finding_id); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="rounded-xl border border-dashed border-slate-300 px-4 py-10 text-center">
                            <p class="text-sm font-medium text-slate-600">
                                Belum ada dokumentasi foto untuk inspeksi ini.
                            </p>
                            <p class="mt-1 text-xs text-slate-400">
                                Foto yang diunggah akan muncul di bagian ini.
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>

            
            <?php if(isset($inspection->activityLogs) && $inspection->activityLogs->isNotEmpty()): ?>
                <section class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div class="border-b border-slate-100 px-6 py-5">
                        <h3 class="text-base font-bold text-slate-800">
                            Riwayat Aktivitas
                        </h3>
                        <p class="mt-1 text-sm text-slate-500">
                            Catatan aktivitas yang dilakukan pada inspeksi ini.
                        </p>
                    </div>

                    <div class="divide-y divide-slate-100">
                        <?php $__currentLoopData = $inspection->activityLogs->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-5">
                                <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                    <p class="text-sm font-medium leading-6 text-slate-800">
                                        <?php echo e($log->description ?? $log->activity); ?>

                                    </p>

                                    <p class="shrink-0 text-xs text-slate-500">
                                        <?php echo e($log->created_at?->format('d/m/Y H:i')); ?>

                                    </p>
                                </div>

                                <?php if($log->user): ?>
                                    <p class="mt-2 text-xs text-slate-500">
                                        Oleh: <?php echo e($log->user->name); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Ideapad Gaming 3\sistem-checklist\resources\views/inspections/show.blade.php ENDPATH**/ ?>